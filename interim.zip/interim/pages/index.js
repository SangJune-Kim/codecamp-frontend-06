import BoardListPage from "./boards";

export default function Home() {
  return <BoardListPage />;
}
