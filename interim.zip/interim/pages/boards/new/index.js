import BoardWrite from "../../../src/components/units/board/write/BoardWrite.container";

export default function BoardNewPage() {
  return <BoardWrite />;
}
