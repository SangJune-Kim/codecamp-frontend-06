import BoardDetail from "../../../src/components/units/board/detail/BoardDetail.container";

const BoardDetailPage = () => {
  return (
    <div>
      <BoardDetail />
    </div>
  );
};

export default BoardDetailPage;
