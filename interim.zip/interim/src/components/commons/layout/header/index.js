import styled from "@emotion/styled";

const Wrapper = styled.div`
  background-color: red;
  width: 100%;
  height: 700px;
`;

export default function LayoutHeader() {
  return (
    <Wrapper>
      <div></div>
    </Wrapper>
  );
}
