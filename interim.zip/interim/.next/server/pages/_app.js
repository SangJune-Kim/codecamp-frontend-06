/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd/dist/antd.css */ \"./node_modules/antd/dist/antd.css\");\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_commons_styles_globalStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../src/commons/styles/globalStyles */ \"./src/commons/styles/globalStyles.js\");\n/* harmony import */ var _src_components_commons_layout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../src/components/commons/layout */ \"./src/components/commons/layout/index.js\");\n/* harmony import */ var apollo_upload_client__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! apollo-upload-client */ \"apollo-upload-client\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apollo_upload_client__WEBPACK_IMPORTED_MODULE_7__]);\napollo_upload_client__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    const uploadLink = (0,apollo_upload_client__WEBPACK_IMPORTED_MODULE_7__.createUploadLink)({\n        uri: \"http://backend06.codebootcamp.co.kr/graphql\"\n    });\n    const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloClient({\n        link: _apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloLink.from([\n            uploadLink\n        ]),\n        cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_2__.InMemoryCache()\n    });\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloProvider, {\n        client: client,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react__WEBPACK_IMPORTED_MODULE_3__.Global, {\n                styles: _src_commons_styles_globalStyles__WEBPACK_IMPORTED_MODULE_5__.globalStyles\n            }, void 0, false, {\n                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/pages/_app.js\",\n                lineNumber: 26,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_commons_layout__WEBPACK_IMPORTED_MODULE_6__[\"default\"], {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/pages/_app.js\",\n                    lineNumber: 28,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/pages/_app.js\",\n                lineNumber: 27,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/pages/_app.js\",\n        lineNumber: 25,\n        columnNumber: 5\n    }, this));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUE4QjtBQU1QO0FBQ2dCO0FBQ1o7QUFDc0M7QUFDWjtBQUNFO1NBRTlDUSxLQUFLLENBQUMsQ0FBQyxDQUFDQyxTQUFTLEdBQUVDLFNBQVMsRUFBQyxDQUFDLEVBQUUsQ0FBQztJQUN4QyxLQUFLLENBQUNDLFVBQVUsR0FBR0osc0VBQWdCLENBQUMsQ0FBQztRQUNuQ0ssR0FBRyxFQUFFLENBQTZDO0lBQ3BELENBQUM7SUFFRCxLQUFLLENBQUNDLE1BQU0sR0FBRyxHQUFHLENBQUNiLHdEQUFZLENBQUMsQ0FBQztRQUMvQmMsSUFBSSxFQUFFYiwyREFBZSxDQUFDLENBQUNVO1lBQUFBLFVBQVU7UUFBQSxDQUFDO1FBQ2xDSyxLQUFLLEVBQUUsR0FBRyxDQUFDYix5REFBYTtJQUMxQixDQUFDO0lBRUQsTUFBTSw2RUFDSEQsMERBQWM7UUFBQ1csTUFBTSxFQUFFQSxNQUFNOzt3RkFDM0JULGtEQUFNO2dCQUFDYSxNQUFNLEVBQUVaLDBFQUFZOzs7Ozs7d0ZBQzNCQyxzRUFBTTtzR0FDSkcsU0FBUzt1QkFBS0MsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJaEMsQ0FBQztBQUVELGlFQUFlRixLQUFLLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9pbnRlcmltLy4vcGFnZXMvX2FwcC5qcz9lMGFkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9nbG9iYWxzLmNzc1wiO1xuaW1wb3J0IHtcbiAgQXBvbGxvQ2xpZW50LFxuICBBcG9sbG9MaW5rLFxuICBBcG9sbG9Qcm92aWRlcixcbiAgSW5NZW1vcnlDYWNoZSxcbn0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5pbXBvcnQgeyBHbG9iYWwgfSBmcm9tIFwiQGVtb3Rpb24vcmVhY3RcIjtcbmltcG9ydCBcImFudGQvZGlzdC9hbnRkLmNzc1wiO1xuaW1wb3J0IHsgZ2xvYmFsU3R5bGVzIH0gZnJvbSBcIi4uL3NyYy9jb21tb25zL3N0eWxlcy9nbG9iYWxTdHlsZXNcIjtcbmltcG9ydCBMYXlvdXQgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL2NvbW1vbnMvbGF5b3V0XCI7XG5pbXBvcnQgeyBjcmVhdGVVcGxvYWRMaW5rIH0gZnJvbSBcImFwb2xsby11cGxvYWQtY2xpZW50XCI7XG5cbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICBjb25zdCB1cGxvYWRMaW5rID0gY3JlYXRlVXBsb2FkTGluayh7XG4gICAgdXJpOiBcImh0dHA6Ly9iYWNrZW5kMDYuY29kZWJvb3RjYW1wLmNvLmtyL2dyYXBocWxcIixcbiAgfSk7XG5cbiAgY29uc3QgY2xpZW50ID0gbmV3IEFwb2xsb0NsaWVudCh7XG4gICAgbGluazogQXBvbGxvTGluay5mcm9tKFt1cGxvYWRMaW5rXSksXG4gICAgY2FjaGU6IG5ldyBJbk1lbW9yeUNhY2hlKCksXG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPEFwb2xsb1Byb3ZpZGVyIGNsaWVudD17Y2xpZW50fT5cbiAgICAgIDxHbG9iYWwgc3R5bGVzPXtnbG9iYWxTdHlsZXN9IC8+XG4gICAgICA8TGF5b3V0PlxuICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICA8L0xheW91dD5cbiAgICA8L0Fwb2xsb1Byb3ZpZGVyPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBNeUFwcDtcbiJdLCJuYW1lcyI6WyJBcG9sbG9DbGllbnQiLCJBcG9sbG9MaW5rIiwiQXBvbGxvUHJvdmlkZXIiLCJJbk1lbW9yeUNhY2hlIiwiR2xvYmFsIiwiZ2xvYmFsU3R5bGVzIiwiTGF5b3V0IiwiY3JlYXRlVXBsb2FkTGluayIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwidXBsb2FkTGluayIsInVyaSIsImNsaWVudCIsImxpbmsiLCJmcm9tIiwiY2FjaGUiLCJzdHlsZXMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./src/commons/styles/globalStyles.js":
/*!********************************************!*\
  !*** ./src/commons/styles/globalStyles.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"globalStyles\": () => (/* binding */ globalStyles)\n/* harmony export */ });\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_0__);\n\n// import \"slick-carousel/slick/slick.css\";\n// import \"slick-carousel/slick/slick-theme.css\";\nconst globalStyles = _emotion_react__WEBPACK_IMPORTED_MODULE_0__.css`\n  * {\n    margin: 0;\n    box-sizing: border-box;\n    font-size: 15px;\n    font-family: \"myfont\", \"SUIT-ExtraBold\", \"SUIT-Bold\";\n  }\n  @font-face {\n    font-family: \"myfont\";\n    src: url(\"/fonts/SUIT-ttf/SUIT-Regular.ttf\");\n  }\n  @font-face {\n    font-family: \"SUIT-ExtraBold\";\n    src: url(\"/fonts/SUIT-ttf/SUIT-ExtraBold.ttf\");\n  }\n  @font-face {\n    font-family: \"SUIT-Bold\";\n    src: url(\"/fonts/SUIT-ttf/SUIT-Bold.ttf\");\n  }\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdHlsZXMvZ2xvYmFsU3R5bGVzLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFvQztBQUNwQyxFQUEyQztBQUMzQyxFQUFpRDtBQUUxQyxLQUFLLENBQUNDLFlBQVksR0FBR0QsK0NBQUcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CaEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9pbnRlcmltLy4vc3JjL2NvbW1vbnMvc3R5bGVzL2dsb2JhbFN0eWxlcy5qcz85ZjIzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNzcyB9IGZyb20gXCJAZW1vdGlvbi9yZWFjdFwiO1xuLy8gaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2suY3NzXCI7XG4vLyBpbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay10aGVtZS5jc3NcIjtcblxuZXhwb3J0IGNvbnN0IGdsb2JhbFN0eWxlcyA9IGNzc2BcbiAgKiB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIGZvbnQtZmFtaWx5OiBcIm15Zm9udFwiLCBcIlNVSVQtRXh0cmFCb2xkXCIsIFwiU1VJVC1Cb2xkXCI7XG4gIH1cbiAgQGZvbnQtZmFjZSB7XG4gICAgZm9udC1mYW1pbHk6IFwibXlmb250XCI7XG4gICAgc3JjOiB1cmwoXCIvZm9udHMvU1VJVC10dGYvU1VJVC1SZWd1bGFyLnR0ZlwiKTtcbiAgfVxuICBAZm9udC1mYWNlIHtcbiAgICBmb250LWZhbWlseTogXCJTVUlULUV4dHJhQm9sZFwiO1xuICAgIHNyYzogdXJsKFwiL2ZvbnRzL1NVSVQtdHRmL1NVSVQtRXh0cmFCb2xkLnR0ZlwiKTtcbiAgfVxuICBAZm9udC1mYWNlIHtcbiAgICBmb250LWZhbWlseTogXCJTVUlULUJvbGRcIjtcbiAgICBzcmM6IHVybChcIi9mb250cy9TVUlULXR0Zi9TVUlULUJvbGQudHRmXCIpO1xuICB9XG5gO1xuIl0sIm5hbWVzIjpbImNzcyIsImdsb2JhbFN0eWxlcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/styles/globalStyles.js\n");

/***/ }),

/***/ "./src/components/commons/layout/index.js":
/*!************************************************!*\
  !*** ./src/components/commons/layout/index.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navigation */ \"./src/components/commons/layout/navigation/index.js\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_2__);\n\n// import LayoutHeader from \"./header\";\n\n\nconst Body = (_emotion_styled__WEBPACK_IMPORTED_MODULE_2___default().div)`\n  width: 100%;\n  height: 708px;\n  /* background-color: black; */\n`;\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_2___default().div)`\n  display: flex;\n  width: 1024px;\n  height: 760px;\n  padding: 30px 20px;\n  margin: 0 auto;\n`;\nfunction Layout(props) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_navigation__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/index.js\",\n                lineNumber: 22,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Body, {\n                children: props.children\n            }, void 0, false, {\n                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/index.js\",\n                lineNumber: 23,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/index.js\",\n        lineNumber: 21,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsRUFBdUM7QUFDSTtBQUNQO0FBRXBDLEtBQUssQ0FBQ0UsSUFBSSxHQUFHRCw0REFBVSxDQUFDOzs7O0FBSXhCO0FBRUEsS0FBSyxDQUFDRyxPQUFPLEdBQUdILDREQUFVLENBQUM7Ozs7OztBQU0zQjtBQUVlLFFBQVEsQ0FBQ0ksTUFBTSxDQUFDQyxLQUFLLEVBQUUsQ0FBQztJQUNyQyxNQUFNLDZFQUNIRixPQUFPOzt3RkFDTEosbURBQWdCOzs7Ozt3RkFDaEJFLElBQUk7MEJBQUVJLEtBQUssQ0FBQ0MsUUFBUTs7Ozs7Ozs7Ozs7O0FBRzNCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9pbnRlcmltLy4vc3JjL2NvbXBvbmVudHMvY29tbW9ucy9sYXlvdXQvaW5kZXguanM/YTBhZiJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpbXBvcnQgTGF5b3V0SGVhZGVyIGZyb20gXCIuL2hlYWRlclwiO1xuaW1wb3J0IExheW91dE5hdmlnYXRpb24gZnJvbSBcIi4vbmF2aWdhdGlvblwiO1xuaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XG5cbmNvbnN0IEJvZHkgPSBzdHlsZWQuZGl2YFxuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA3MDhweDtcbiAgLyogYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7ICovXG5gO1xuXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAgd2lkdGg6IDEwMjRweDtcbiAgaGVpZ2h0OiA3NjBweDtcbiAgcGFkZGluZzogMzBweCAyMHB4O1xuICBtYXJnaW46IDAgYXV0bztcbmA7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dChwcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxXcmFwcGVyPlxuICAgICAgPExheW91dE5hdmlnYXRpb24gLz5cbiAgICAgIDxCb2R5Pntwcm9wcy5jaGlsZHJlbn08L0JvZHk+XG4gICAgPC9XcmFwcGVyPlxuICApO1xufVxuIl0sIm5hbWVzIjpbIkxheW91dE5hdmlnYXRpb24iLCJzdHlsZWQiLCJCb2R5IiwiZGl2IiwiV3JhcHBlciIsIkxheW91dCIsInByb3BzIiwiY2hpbGRyZW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/commons/layout/index.js\n");

/***/ }),

/***/ "./src/components/commons/layout/navigation/index.js":
/*!***********************************************************!*\
  !*** ./src/components/commons/layout/navigation/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutNavigation)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  /* background-color: yellow; */\n  width: 200px;\n  height: 708px;\n  margin-right: 20px;\n  box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.05);\n  border-radius: 10px;\n  padding: 30px 20px;\n`;\n// TALKR 부분\nconst HeadWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  margin-bottom: 30px;\n  font-size: 16px;\n  font-weight: 800;\n  font-family: \"SUIT-ExtraBold\";\n`;\nconst HeadIcon = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`\n  margin-right: 5px;\n`;\nconst HeadLine = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  border-bottom: 1px solid #e5e5e5;\n  margin-bottom: 30px;\n`;\n// 메뉴 부분\nconst MenuWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  display: flex;\n  flex-direction: column;\n`;\nconst MenuBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  display: flex;\n  margin-bottom: 20px;\n  cursor: pointer;\n`;\nconst ListIcon = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`\n  margin-right: 10px;\n`;\nfunction LayoutNavigation() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const onClickMoveBoardList = ()=>{\n        router.push(`/boards`);\n    };\n    const onClickMoveBoardNew = ()=>{\n        router.push(`/boards/new`);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeadWrapper, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeadIcon, {\n                        src: \"/images/TALKR.png\"\n                    }, void 0, false, {\n                        fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                        lineNumber: 62,\n                        columnNumber: 9\n                    }, this),\n                    \"TALKR\"\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                lineNumber: 61,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeadLine, {}, void 0, false, {\n                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                lineNumber: 65,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(MenuWrapper, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(MenuBox, {\n                        onClick: onClickMoveBoardList,\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(ListIcon, {\n                                src: \"/images/ic_list.png\"\n                            }, void 0, false, {\n                                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                                lineNumber: 68,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                children: \"전체 글 보기\"\n                            }, void 0, false, {\n                                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                                lineNumber: 69,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                        lineNumber: 67,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(MenuBox, {\n                        onClick: onClickMoveBoardNew,\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(ListIcon, {\n                                src: \"/images/ic_new.png\"\n                            }, void 0, false, {\n                                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                                lineNumber: 72,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                children: \"새 글 작성\"\n                            }, void 0, false, {\n                                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                                lineNumber: 73,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                        lineNumber: 71,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n                lineNumber: 66,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/sangjunekim/Desktop/codecamp_FE 06/interim/src/components/commons/layout/navigation/index.js\",\n        lineNumber: 60,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9uYXZpZ2F0aW9uL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQW9DO0FBQ0c7QUFFdkMsS0FBSyxDQUFDRSxPQUFPLEdBQUdGLDREQUFVLENBQUM7Ozs7Ozs7O0FBUTNCO0FBRUEsRUFBVztBQUNQLEtBQUMsQ0FBQ0ksV0FBVyxHQUFHSiw0REFBVSxDQUFDOzs7OztBQUsvQjtBQUVBLEtBQUssQ0FBQ0ssUUFBUSxHQUFHTCw0REFBVSxDQUFDOztBQUU1QjtBQUVBLEtBQUssQ0FBQ08sUUFBUSxHQUFHUCw0REFBVSxDQUFDOzs7QUFHNUI7QUFFQSxFQUFRO0FBRUEsS0FBSCxDQUFDUSxXQUFXLEdBQUdSLDREQUFVLENBQUM7OztBQUcvQjtBQUVBLEtBQUssQ0FBQ1MsT0FBTyxHQUFHVCw0REFBVSxDQUFDOzs7O0FBSTNCO0FBRUEsS0FBSyxDQUFDVSxRQUFRLEdBQUdWLDREQUFVLENBQUM7O0FBRTVCO0FBRWUsUUFBUSxDQUFDVyxnQkFBZ0IsR0FBRyxDQUFDO0lBQzFDLEtBQUssQ0FBQ0MsTUFBTSxHQUFHWCxzREFBUztJQUV4QixLQUFLLENBQUNZLG9CQUFvQixPQUFTLENBQUM7UUFDbENELE1BQU0sQ0FBQ0UsSUFBSSxFQUFFLE9BQU87SUFDdEIsQ0FBQztJQUVELEtBQUssQ0FBQ0MsbUJBQW1CLE9BQVMsQ0FBQztRQUNqQ0gsTUFBTSxDQUFDRSxJQUFJLEVBQUUsV0FBVztJQUMxQixDQUFDO0lBRUQsTUFBTSw2RUFDSFosT0FBTzs7d0ZBQ0xFLFdBQVc7O2dHQUNUQyxRQUFRO3dCQUFDVyxHQUFHLEVBQUMsQ0FBbUI7Ozs7OztvQkFBRyxDQUV0Qzs7Ozs7Ozt3RkFDQ1QsUUFBUTs7Ozs7d0ZBQ1JDLFdBQVc7O2dHQUNUQyxPQUFPO3dCQUFDUSxPQUFPLEVBQUVKLG9CQUFvQjs7d0dBQ25DSCxRQUFRO2dDQUFDTSxHQUFHLEVBQUMsQ0FBcUI7Ozs7Ozt3R0FDbENiLENBQUc7MENBQUMsQ0FBTzs7Ozs7Ozs7Ozs7O2dHQUVITSxPQUFIO3dCQUFDUSxPQUFPLEVBQUVGLG1CQUFtQjs7d0dBQ2xDTCxRQUFRO2dDQUFDTSxHQUFHLEVBQUMsQ0FBb0I7Ozs7Ozt3R0FDakNiLENBQUc7MENBQUMsQ0FBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS3JCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9pbnRlcmltLy4vc3JjL2NvbXBvbmVudHMvY29tbW9ucy9sYXlvdXQvbmF2aWdhdGlvbi9pbmRleC5qcz9jOWNmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XG5cbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICAvKiBiYWNrZ3JvdW5kLWNvbG9yOiB5ZWxsb3c7ICovXG4gIHdpZHRoOiAyMDBweDtcbiAgaGVpZ2h0OiA3MDhweDtcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xuICBib3gtc2hhZG93OiAwcHggNXB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjA1KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgcGFkZGluZzogMzBweCAyMHB4O1xuYDtcblxuLy8gVEFMS1Ig67aA67aEXG5jb25zdCBIZWFkV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgZm9udC1mYW1pbHk6IFwiU1VJVC1FeHRyYUJvbGRcIjtcbmA7XG5cbmNvbnN0IEhlYWRJY29uID0gc3R5bGVkLmltZ2BcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG5gO1xuXG5jb25zdCBIZWFkTGluZSA9IHN0eWxlZC5kaXZgXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZTVlNWU1O1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuYDtcblxuLy8g66mU64m0IOu2gOu2hFxuXG5jb25zdCBNZW51V3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5gO1xuXG5jb25zdCBNZW51Qm94ID0gc3R5bGVkLmRpdmBcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuYDtcblxuY29uc3QgTGlzdEljb24gPSBzdHlsZWQuaW1nYFxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG5gO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXROYXZpZ2F0aW9uKCkge1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblxuICBjb25zdCBvbkNsaWNrTW92ZUJvYXJkTGlzdCA9ICgpID0+IHtcbiAgICByb3V0ZXIucHVzaChgL2JvYXJkc2ApO1xuICB9O1xuXG4gIGNvbnN0IG9uQ2xpY2tNb3ZlQm9hcmROZXcgPSAoKSA9PiB7XG4gICAgcm91dGVyLnB1c2goYC9ib2FyZHMvbmV3YCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8V3JhcHBlcj5cbiAgICAgIDxIZWFkV3JhcHBlcj5cbiAgICAgICAgPEhlYWRJY29uIHNyYz1cIi9pbWFnZXMvVEFMS1IucG5nXCIgLz5cbiAgICAgICAgVEFMS1JcbiAgICAgIDwvSGVhZFdyYXBwZXI+XG4gICAgICA8SGVhZExpbmU+PC9IZWFkTGluZT5cbiAgICAgIDxNZW51V3JhcHBlcj5cbiAgICAgICAgPE1lbnVCb3ggb25DbGljaz17b25DbGlja01vdmVCb2FyZExpc3R9PlxuICAgICAgICAgIDxMaXN0SWNvbiBzcmM9XCIvaW1hZ2VzL2ljX2xpc3QucG5nXCIgLz5cbiAgICAgICAgICA8ZGl2PuyghOyytCDquIAg67O06riwPC9kaXY+XG4gICAgICAgIDwvTWVudUJveD5cbiAgICAgICAgPE1lbnVCb3ggb25DbGljaz17b25DbGlja01vdmVCb2FyZE5ld30+XG4gICAgICAgICAgPExpc3RJY29uIHNyYz1cIi9pbWFnZXMvaWNfbmV3LnBuZ1wiIC8+XG4gICAgICAgICAgPGRpdj7sg4gg6riAIOyekeyEsTwvZGl2PlxuICAgICAgICA8L01lbnVCb3g+XG4gICAgICA8L01lbnVXcmFwcGVyPlxuICAgIDwvV3JhcHBlcj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJ1c2VSb3V0ZXIiLCJXcmFwcGVyIiwiZGl2IiwiSGVhZFdyYXBwZXIiLCJIZWFkSWNvbiIsImltZyIsIkhlYWRMaW5lIiwiTWVudVdyYXBwZXIiLCJNZW51Qm94IiwiTGlzdEljb24iLCJMYXlvdXROYXZpZ2F0aW9uIiwicm91dGVyIiwib25DbGlja01vdmVCb2FyZExpc3QiLCJwdXNoIiwib25DbGlja01vdmVCb2FyZE5ldyIsInNyYyIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/commons/layout/navigation/index.js\n");

/***/ }),

/***/ "./node_modules/antd/dist/antd.css":
/*!*****************************************!*\
  !*** ./node_modules/antd/dist/antd.css ***!
  \*****************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/react":
/*!*********************************!*\
  !*** external "@emotion/react" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/react");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/styled");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "apollo-upload-client":
/*!***************************************!*\
  !*** external "apollo-upload-client" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = import("apollo-upload-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();